package oop;

public class MainClass {

	public static void main(String[] args) {
		GraphicsSystem obj = new GraphicsSystem(); //Creating object of GraphicsSystem
		obj.about();//Calling about function
	}

}
